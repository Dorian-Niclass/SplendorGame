var searchData=
[
  ['name',['Name',['../class_splendor_1_1_player.html#a15abd489e523e11b6beb4b186783e47f',1,'Splendor::Player']]]
];
