var searchData=
[
  ['saphir',['Saphir',['../namespace_splendor.html#abc955fe800ad5f701f777df0a2a29dc2ab4c3620381991c7f803f9f0beef133e7',1,'Splendor']]]
];
