var searchData=
[
  ['dispose',['Dispose',['../class_splendor_1_1_add_player_form.html#a855febb2faf18bda813e2e7b368a25fe',1,'Splendor.AddPlayerForm.Dispose()'],['../class_splendor_1_1frm_splendor.html#a749f4f1d67c78e74aa1a55aa6fdd754b',1,'Splendor.frmSplendor.Dispose()']]]
];
