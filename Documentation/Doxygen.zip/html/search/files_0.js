var searchData=
[
  ['addplayerform_2ecs',['AddPlayerForm.cs',['../_add_player_form_8cs.html',1,'']]],
  ['addplayerform_2edesigner_2ecs',['AddPlayerForm.Designer.cs',['../_add_player_form_8_designer_8cs.html',1,'']]],
  ['assemblyinfo_2ecs',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
