var searchData=
[
  ['prestigept',['PrestigePt',['../class_splendor_1_1_card.html#a117119ceac083b7b7d39f11e5bbd7225',1,'Splendor::Card']]]
];
