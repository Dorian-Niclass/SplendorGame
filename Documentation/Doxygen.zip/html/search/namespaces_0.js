var searchData=
[
  ['properties',['Properties',['../namespace_splendor_1_1_properties.html',1,'Splendor']]],
  ['splendor',['Splendor',['../namespace_splendor.html',1,'']]]
];
