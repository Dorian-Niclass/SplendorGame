var searchData=
[
  ['properties',['Properties',['../namespace_splendor_1_1_properties.html',1,'Splendor']]],
  ['saphir',['Saphir',['../namespace_splendor.html#abc955fe800ad5f701f777df0a2a29dc2ab4c3620381991c7f803f9f0beef133e7',1,'Splendor']]],
  ['setcard',['SetCard',['../class_splendor_1_1_card_text.html#ae164c4a76a0b9991b239ebbab536722d',1,'Splendor::CardText']]],
  ['settings_2edesigner_2ecs',['Settings.Designer.cs',['../_settings_8_designer_8cs.html',1,'']]],
  ['splendor',['Splendor',['../namespace_splendor.html',1,'']]]
];
