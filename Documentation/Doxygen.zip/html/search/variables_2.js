var searchData=
[
  ['players',['players',['../class_splendor_1_1frm_splendor.html#ac946e6c25d1f08459eb46ebdb1cf2020',1,'Splendor::frmSplendor']]]
];
