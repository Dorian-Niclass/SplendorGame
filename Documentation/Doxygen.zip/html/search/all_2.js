var searchData=
[
  ['diamand',['Diamand',['../namespace_splendor.html#abc955fe800ad5f701f777df0a2a29dc2aaf25488f58f7ac25bd60be893e7c3cd1',1,'Splendor']]],
  ['dispose',['Dispose',['../class_splendor_1_1_add_player_form.html#a855febb2faf18bda813e2e7b368a25fe',1,'Splendor.AddPlayerForm.Dispose()'],['../class_splendor_1_1frm_splendor.html#a749f4f1d67c78e74aa1a55aa6fdd754b',1,'Splendor.frmSplendor.Dispose()']]]
];
