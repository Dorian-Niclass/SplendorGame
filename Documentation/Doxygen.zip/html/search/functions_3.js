var searchData=
[
  ['frmsplendor',['frmSplendor',['../class_splendor_1_1frm_splendor.html#ad9c938893d23192acb1996053e3ea87b',1,'Splendor::frmSplendor']]]
];
