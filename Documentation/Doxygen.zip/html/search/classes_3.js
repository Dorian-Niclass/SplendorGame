var searchData=
[
  ['player',['Player',['../class_splendor_1_1_player.html',1,'Splendor']]]
];
