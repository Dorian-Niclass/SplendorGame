var searchData=
[
  ['enableclicplay',['enableClicPlay',['../class_splendor_1_1frm_splendor.html#a42fbff589ff8f7c11e94609b872d9aed',1,'Splendor::frmSplendor']]]
];
