var searchData=
[
  ['addplayerform',['AddPlayerForm',['../class_splendor_1_1_add_player_form.html#a1a70bedb4e5bb150e146c7938092750b',1,'Splendor::AddPlayerForm']]]
];
