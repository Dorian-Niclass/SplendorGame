var searchData=
[
  ['getlistcardaccordingtolevel',['GetListCardAccordingToLevel',['../class_splendor_1_1_connection_d_b.html#abcd995d0fa97aa5f3a40ff5c23b22502',1,'Splendor::ConnectionDB']]],
  ['getprestige',['GetPrestige',['../class_splendor_1_1_player.html#a8c9895cc3d62a126eaf1e504c23f6784',1,'Splendor::Player']]],
  ['getressources',['GetRessources',['../class_splendor_1_1_player.html#a6fbec3d075cd8915b8ebeb54d215cd56',1,'Splendor::Player']]]
];
