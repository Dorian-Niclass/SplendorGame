var searchData=
[
  ['level',['Level',['../class_splendor_1_1_card.html#aadc9953aeb322c82e04fbd9b5a3b996d',1,'Splendor::Card']]]
];
