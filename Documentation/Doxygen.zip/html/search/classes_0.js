var searchData=
[
  ['addplayerform',['AddPlayerForm',['../class_splendor_1_1_add_player_form.html',1,'Splendor']]]
];
