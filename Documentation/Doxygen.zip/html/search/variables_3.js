var searchData=
[
  ['row',['row',['../class_splendor_1_1_card_text.html#aba3b71d0fdb730526a4d3683b88d22dd',1,'Splendor::CardText']]]
];
