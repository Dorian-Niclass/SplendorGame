var searchData=
[
  ['addplayerform',['AddPlayerForm',['../class_splendor_1_1_add_player_form.html',1,'Splendor.AddPlayerForm'],['../class_splendor_1_1_add_player_form.html#a1a70bedb4e5bb150e146c7938092750b',1,'Splendor.AddPlayerForm.AddPlayerForm()']]],
  ['addplayerform_2ecs',['AddPlayerForm.cs',['../_add_player_form_8cs.html',1,'']]],
  ['addplayerform_2edesigner_2ecs',['AddPlayerForm.Designer.cs',['../_add_player_form_8_designer_8cs.html',1,'']]],
  ['assemblyinfo_2ecs',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
