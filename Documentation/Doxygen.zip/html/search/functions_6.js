var searchData=
[
  ['refreshcard',['RefreshCard',['../class_splendor_1_1_card_text.html#ad2d52aae3243d0e68529bc86ac7ca35e',1,'Splendor::CardText']]]
];
