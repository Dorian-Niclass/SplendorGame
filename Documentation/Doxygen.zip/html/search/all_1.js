var searchData=
[
  ['card',['Card',['../class_splendor_1_1_card.html',1,'Splendor.Card'],['../class_splendor_1_1_card_text.html#a801df4bc874261ea17c9ed66bb192289',1,'Splendor.CardText.Card()'],['../class_splendor_1_1_card.html#a005c3818744fadfab203419e895daf85',1,'Splendor.Card.Card()']]],
  ['card_2ecs',['Card.cs',['../_card_8cs.html',1,'']]],
  ['cards',['Cards',['../class_splendor_1_1_player.html#a4dd6385c9940479dbed7d1c9e0afe7a6',1,'Splendor::Player']]],
  ['cardtext',['CardText',['../class_splendor_1_1_card_text.html',1,'Splendor.CardText'],['../class_splendor_1_1_card_text.html#a022166b2241fbf79fab438e785031681',1,'Splendor.CardText.CardText()']]],
  ['cardtext_2ecs',['CardText.cs',['../_card_text_8cs.html',1,'']]],
  ['coins',['Coins',['../class_splendor_1_1_player.html#a54a5d419d0c88848e67990ce507d14b8',1,'Splendor::Player']]],
  ['col',['col',['../class_splendor_1_1_card_text.html#ad94dde2ffef717d944869686b35633c7',1,'Splendor::CardText']]],
  ['connectiondb',['ConnectionDB',['../class_splendor_1_1_connection_d_b.html',1,'Splendor.ConnectionDB'],['../class_splendor_1_1_connection_d_b.html#aaaa5c66d4f12702d36a76dd21beb62c4',1,'Splendor.ConnectionDB.ConnectionDB()']]],
  ['connectiondb_2ecs',['ConnectionDB.cs',['../_connection_d_b_8cs.html',1,'']]],
  ['cost',['Cost',['../class_splendor_1_1_card.html#a24d04e720c811454046d458c4ebb91fe',1,'Splendor::Card']]]
];
