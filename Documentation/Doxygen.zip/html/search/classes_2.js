var searchData=
[
  ['frmsplendor',['frmSplendor',['../class_splendor_1_1frm_splendor.html',1,'Splendor']]]
];
