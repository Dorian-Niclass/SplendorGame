var searchData=
[
  ['setcard',['SetCard',['../class_splendor_1_1_card_text.html#ae164c4a76a0b9991b239ebbab536722d',1,'Splendor::CardText']]]
];
