var searchData=
[
  ['rubis',['Rubis',['../namespace_splendor.html#abc955fe800ad5f701f777df0a2a29dc2a325687fe48a90ae4d55ca5c97df8cafc',1,'Splendor']]]
];
