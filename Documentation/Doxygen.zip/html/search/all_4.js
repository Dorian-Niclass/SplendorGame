var searchData=
[
  ['form1_2ecs',['Form1.cs',['../_form1_8cs.html',1,'']]],
  ['form1_2edesigner_2ecs',['Form1.Designer.cs',['../_form1_8_designer_8cs.html',1,'']]],
  ['frmsplendor',['frmSplendor',['../class_splendor_1_1frm_splendor.html',1,'Splendor.frmSplendor'],['../class_splendor_1_1frm_splendor.html#ad9c938893d23192acb1996053e3ea87b',1,'Splendor.frmSplendor.frmSplendor()']]]
];
