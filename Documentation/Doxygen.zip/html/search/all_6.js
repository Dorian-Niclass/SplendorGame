var searchData=
[
  ['id',['Id',['../class_splendor_1_1_player.html#a5616e3562be3e8800f9e959e7cf75194',1,'Splendor::Player']]]
];
