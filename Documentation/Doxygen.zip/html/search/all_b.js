var searchData=
[
  ['refreshcard',['RefreshCard',['../class_splendor_1_1_card_text.html#ad2d52aae3243d0e68529bc86ac7ca35e',1,'Splendor::CardText']]],
  ['resources_2edesigner_2ecs',['Resources.Designer.cs',['../_resources_8_designer_8cs.html',1,'']]],
  ['ress',['Ress',['../class_splendor_1_1_card.html#afcfaa7ea5072b3cd30c04adddc8dd5c7',1,'Splendor::Card']]],
  ['ressources',['Ressources',['../namespace_splendor.html#abc955fe800ad5f701f777df0a2a29dc2',1,'Splendor']]],
  ['ressources_2ecs',['Ressources.cs',['../_ressources_8cs.html',1,'']]],
  ['row',['row',['../class_splendor_1_1_card_text.html#aba3b71d0fdb730526a4d3683b88d22dd',1,'Splendor::CardText']]],
  ['rubis',['Rubis',['../namespace_splendor.html#abc955fe800ad5f701f777df0a2a29dc2a325687fe48a90ae4d55ca5c97df8cafc',1,'Splendor']]]
];
