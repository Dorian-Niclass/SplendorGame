var searchData=
[
  ['coins',['Coins',['../class_splendor_1_1_player.html#a54a5d419d0c88848e67990ce507d14b8',1,'Splendor::Player']]],
  ['col',['col',['../class_splendor_1_1_card_text.html#ad94dde2ffef717d944869686b35633c7',1,'Splendor::CardText']]]
];
