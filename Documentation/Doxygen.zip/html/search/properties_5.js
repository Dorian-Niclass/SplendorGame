var searchData=
[
  ['ress',['Ress',['../class_splendor_1_1_card.html#afcfaa7ea5072b3cd30c04adddc8dd5c7',1,'Splendor::Card']]]
];
